create
    definer = ostechnix@localhost procedure GetProductsForCategory(IN categoryId int)
BEGIN
    SELECT DISTINCT p.id AS product_id, p.name AS product_name
    FROM Product p
    JOIN Category c ON p.category_id = c.id
    WHERE c.id = categoryId OR c.parent_category_id IN (
        SELECT id FROM Category WHERE parent_category_id = categoryId
        UNION
        SELECT id FROM Category WHERE parent_category_id IN (
            SELECT id FROM Category WHERE parent_category_id = categoryId
        )
    );
END;

